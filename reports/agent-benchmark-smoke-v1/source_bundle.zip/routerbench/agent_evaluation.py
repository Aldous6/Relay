"""Episode-level evaluation with independent environments and durable decisions.

This module imports no model provider and executes no generated code. Callers
supply a generation callback and an explicit manifest; the bundled CLI only
uses a scripted simulation. Hidden references never enter either callback.
"""
from __future__ import annotations

from copy import deepcopy
from contextlib import contextmanager
import hashlib
import importlib.metadata
import inspect
from io import BytesIO
import json
import math
import os
from pathlib import Path
import platform
import time
import zipfile

from relay_router.agent import AgentRequest, AgentState, ModelReply, parse_action
from .agent_tasks import create_environment, validate_task_splits
from .agent_metrics import annotate_costs, summarize, DEFAULT_ROI


def object_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False, separators=(",", ":")).encode()).hexdigest()


def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def _seal(value):
    return {"payload": value, "payload_sha256": object_hash(value)}


def _unseal(path):
    saved = _read(path)
    if (not isinstance(saved, dict) or set(saved) != {"payload", "payload_sha256"}
            or object_hash(saved["payload"]) != saved["payload_sha256"]):
        raise ValueError(f"Checkpoint alterado: {path}")
    return saved["payload"]


def _fingerprint(callback):
    target = callback if inspect.isfunction(callback) else type(callback)
    try:
        source = inspect.getsourcefile(target)
    except TypeError:
        source = None
    return {"module": target.__module__, "name": target.__qualname__,
            "source_sha256": hashlib.sha256(Path(source).read_bytes()).hexdigest()
            if source and Path(source).is_file() else None}


def _sources():
    root = Path(__file__).resolve().parent.parent
    paths = [p for package in ("routerbench", "relay_router") for p in (root / package).rglob("*.py")]
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}


def _source_bundle(config):
    root = Path(__file__).resolve().parent.parent
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in _sources():
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (root / name).read_bytes())
        archive.writestr(zipfile.ZipInfo("configuration.json", date_time=(1980, 1, 1, 0, 0, 0)),
                         json.dumps(config, sort_keys=True, ensure_ascii=False, allow_nan=False))
    return buffer.getvalue()


@contextmanager
def _single_writer(output):
    """An OS lock is released on process death; stale file content is harmless."""
    with (Path(output) / ".writer.lock").open("a+b") as stream:
        stream.seek(0, os.SEEK_END)
        if stream.tell() == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError("Otra ejecución mantiene esta salida bloqueada.") from exc
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == "nt":
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def _validate(config, policies):
    if config.get("schema_version") != 1 or type(config.get("schema_version")) is not int:
        raise ValueError("Se requiere schema_version=1.")
    if config.get("execution_mode") not in {"simulated", "external"}:
        raise ValueError("execution_mode debe declarar simulated o external.")
    if config.get("evaluation_split") not in {"development", "calibration", "evaluation"}:
        raise ValueError("Declarar la partición de episodios.")
    if config.get("independent_validation") is not False:
        raise ValueError("Esta infraestructura inicial no autoriza confirmación independiente.")
    if type(config.get("max_calls")) is not int or not 1 <= config["max_calls"] <= 128:
        raise ValueError("max_calls debe ser un entero entre 1 y 128.")
    if not isinstance(config.get("run_id"), str) or not config["run_id"].strip():
        raise ValueError("run_id es obligatorio.")
    if not isinstance(config.get("generation_manifest"), dict) or not config["generation_manifest"]:
        raise ValueError("Declarar el generador y sus versiones/parámetros.")
    annotate_costs([], config.get("pricing"), config.get("compute_rates"))
    roi = config.get("roi")
    if not isinstance(roi, dict) or set(roi) != set(DEFAULT_ROI):
        raise ValueError("Declarar los tres criterios ROI.")
    for name, value in roi.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
            raise ValueError("Los criterios ROI deben ser números finitos no negativos.")
        if (name != "max_p95_router_seconds" and value > 1) or (name == "max_p95_router_seconds" and value <= 0):
            raise ValueError("Fracciones ROI fuera de rango o latencia no positiva.")
    if type(config.get("seed")) is not int or not 0 <= config["seed"] <= 2**32-1:
        raise ValueError("seed debe ser un entero uint32.")
    if type(config.get("bootstrap_replicates")) is not int or config["bootstrap_replicates"] < 100:
        raise ValueError("bootstrap_replicates debe ser un entero de al menos 100.")
    pair = config.get("models")
    if (not isinstance(pair, dict) or set(pair) != {"strong", "weak"}
            or any(not isinstance(v, str) or not v.strip() for v in pair.values())
            or pair["strong"] == pair["weak"]):
        raise ValueError("Declarar dos identidades de modelos distintas.")
    if not policies or len({p.name for p in policies}) != len(policies):
        raise ValueError("Las políticas requieren nombres únicos.")
    if "always_strong" not in {p.name for p in policies}:
        raise ValueError("Se requiere el control always_strong.")
    for policy in policies:
        if getattr(policy, "strong", None) != pair["strong"] or getattr(policy, "weak", None) != pair["weak"]:
            raise ValueError("La política no coincide con las identidades congeladas.")
        if not callable(getattr(policy, "select", None)) or not callable(getattr(policy, "manifest", None)):
            raise ValueError("La política debe implementar select y manifest.")
    object_hash(config)  # Reject non-JSON/non-finite settings before any call.


def prepare_episodes(tasks, policies, output_dir, config, *, generate=None,
                     environment_factory=create_environment):
    """Freeze inputs without generation. Existing directories must match exactly."""
    tasks, config, policies = deepcopy(tasks), deepcopy(config), list(policies)
    _validate(config, policies)
    split_audit = validate_task_splits({config["evaluation_split"]: tasks})
    if any(type(t["max_steps"]) is not int or not 1 <= t["max_steps"] <= 128 for t in tasks):
        raise ValueError("El límite de cada tarea debe estar entre 1 y 128.")
    # Exercise task/schema construction before any paid/external callback.
    for task in tasks:
        environment_factory(deepcopy(task))
    source_bundle = _source_bundle(config)
    body = {"schema_version": 1, "configuration": config, "tasks": tasks,
            "tasks_sha256": object_hash(tasks), "partition_audit": split_audit,
            "policies": {p.name: p.manifest() for p in policies},
            "policy_sources": {p.name: _fingerprint(p) for p in policies},
            "generation_source": _fingerprint(generate) if generate is not None else None,
            "environment_source": _fingerprint(environment_factory),
            "source_files_sha256": _sources(),
            "source_bundle_sha256": hashlib.sha256(source_bundle).hexdigest(),
            "runtime_versions": {"python": platform.python_version(), **{name: importlib.metadata.version(name)
                                for name in ("numpy", "pandas", "scikit-learn", "joblib")}}}
    frozen = {**body, "freeze_sha256": object_hash(body)}
    output = Path(output_dir)
    manifest = output / "manifest.json"
    if manifest.exists():
        if _read(manifest) != frozen:
            raise ValueError("El código, tareas, generador o políticas cambió desde la congelación.")
    else:
        if output.exists() and any(p.name != ".writer.lock" for p in output.iterdir()):
            raise FileExistsError("La salida debe ser nueva o conservar su manifiesto original.")
        output.mkdir(parents=True, exist_ok=True)
        _write(manifest, frozen)
    archive = output / "source_bundle.zip"
    if archive.exists():
        if hashlib.sha256(archive.read_bytes()).hexdigest() != frozen["source_bundle_sha256"]:
            raise ValueError("El archivo de fuentes congeladas cambió.")
    else:
        archive.write_bytes(source_bundle)
    return frozen


class _Journal:
    def __init__(self, output, freeze, allowed):
        self.path = Path(output) / "journal.json"
        self.freeze = freeze
        self.records = []
        if self.path.exists():
            saved = _unseal(self.path)
            if saved["freeze_sha256"] != freeze:
                raise ValueError("Journal de otra ejecución.")
            self.records = saved["records"]
        previous = freeze
        active, completed = {}, set()
        counts = {}
        for index, record in enumerate(self.records):
            body = {k: v for k, v in record.items() if k != "record_sha256"}
            if (record.get("sequence") != index or record.get("previous_sha256") != previous
                    or object_hash(body) != record.get("record_sha256")):
                raise ValueError("Cadena de eventos alterada.")
            previous = record["record_sha256"]
            key = (record["episode_id"], record["policy"])
            if key not in allowed or key in completed:
                raise ValueError("Evento ajeno a la evaluación o posterior a su cierre.")
            kind = record["kind"]
            if kind == "call_started":
                if key in active or record["data"]["call_index"] != counts.get(key, 0):
                    raise ValueError("Orden de llamadas inconsistente.")
                active[key] = record["data"]
            elif kind == "call_completed":
                if key not in active or record["data"]["call_index"] != active[key]["call_index"]:
                    raise ValueError("Resultado sin llamada iniciada.")
                if record["data"]["model"] != active[key]["model"]:
                    raise ValueError("Modelo cambiado después de decidir.")
                active.pop(key)
                counts[key] = counts.get(key, 0)+1
            elif kind == "episode_completed":
                if key in active and record["data"]["termination"] != "interrupted_not_retried":
                    raise ValueError("Un intento incierto no puede ocultarse.")
                if (record["data"]["episode_id"], record["data"]["policy"]) != key:
                    raise ValueError("Identidad de episodio inconsistente.")
                active.pop(key, None)
                completed.add(key)
            else:
                raise ValueError("Evento desconocido.")

    def append(self, kind, key, data):
        body = {"sequence": len(self.records), "previous_sha256":
                self.records[-1]["record_sha256"] if self.records else self.freeze,
                "episode_id": key[0], "policy": key[1], "kind": kind, "data": deepcopy(data)}
        self.records.append({**body, "record_sha256": object_hash(body)})
        _write(self.path, _seal({"freeze_sha256": self.freeze, "records": self.records}))

    def for_key(self, key):
        return [r for r in self.records if (r["episode_id"], r["policy"]) == key]


def _elapsed(start):
    return max(0., time.perf_counter()-start)


def _provenance(config):
    return {key: config[key] for key in ("execution_mode", "evaluation_split", "independent_validation")}


def _episode(task, policy, events, config, success, termination, elapsed):
    return {"episode_id": task["id"], "source_group": task["source_group"], "family": task["family"],
            "policy": policy.name, "success": bool(success), "termination": termination,
            "events": annotate_costs(events, config["pricing"], config["compute_rates"]),
            "end_to_end_seconds": elapsed, "provenance": _provenance(config)}


def _recover(task, policy, records, config):
    """Conservative recovery: never replay uncertain calls or tool effects."""
    if records[-1]["kind"] == "episode_completed":
        return records[-1]["data"]
    events = [r["data"] for r in records if r["kind"] == "call_completed"]
    if records[-1]["kind"] == "call_started":
        pending = deepcopy(records[-1]["data"])
        pending.update(generation_seconds=None, verification_seconds=None, tool_seconds=None,
                       usage={}, reported_llm_cost_usd=None, error_type="InterruptedGeneration",
                       action=None, final_success=None, response=None)
        events.append(pending)
    elif events and events[-1].get("final_success") is not None:
        # The final evaluator already completed durably. Preserve that known
        # outcome; total wall time remains unknown after an interrupted commit.
        return _episode(task, policy, events, config, events[-1]["final_success"], "final_answer", None)
    return _episode(task, policy, events, config, False, "interrupted_not_retried", None)


def _execute(task, policy, generate, config, journal, environment_factory):
    key = (task["id"], policy.name)
    started = time.perf_counter()
    environment = environment_factory(deepcopy(task))
    tools = environment.tools()
    names = tuple(tool["name"] for tool in tools)
    observation = environment.observation()
    # Provenance is for grouping/audit, not routing or generation features.
    observation = {k: v for k, v in observation.items() if k not in {"task_id", "family", "source_group", "id"}}
    history = [{"role": "tool", "content": {"name": "environment",
                "observation": observation, "tools": tools}}]
    errors, events = [], []
    step, attempt = 0, 0
    limit = min(config["max_calls"], task["max_steps"])
    success, termination = False, "call_budget_exhausted"
    for call_index in range(limit):
        state = AgentState(step=step, attempt=attempt, previous_errors=tuple(errors),
                           available_tools=names, remaining_calls=limit-call_index)
        def request():
            return AgentRequest(prompt=task["prompt"], history=tuple(deepcopy(history)), state=state)
        route_start = time.perf_counter()
        model = policy.select(request())
        router_seconds = _elapsed(route_start)
        if model not in config["models"].values():
            raise ValueError("La política seleccionó un modelo fuera del catálogo congelado.")
        public_request = json.loads(request().serialize())
        event = {"call_index": call_index, "step": step, "attempt": attempt,
                 "is_retry": attempt > 0, "model": model, "router_seconds": router_seconds,
                 "request": public_request, "request_sha256": object_hash(public_request)}
        journal.append("call_started", key, event)  # durable BEFORE external call
        generation_start = time.perf_counter()
        reply, generation_error = None, None
        try:
            reply = generate(model, request())
            if not isinstance(reply, ModelReply):
                raise TypeError("El generador debe devolver ModelReply.")
            reply = reply.snapshot()
            annotate_costs([{**event, "generation_seconds": 0., "verification_seconds": 0.,
                             "tool_seconds": 0., "usage": reply.usage,
                             "reported_llm_cost_usd": reply.cost_usd}], {}, {})
        except Exception as exc:
            generation_error = type(exc).__name__
            reply = None  # Invalid provider contracts never poison the journal.
        generation_seconds = _elapsed(generation_start)
        event.update(generation_seconds=generation_seconds, verification_seconds=0., tool_seconds=0.,
                     usage=deepcopy(reply.usage) if reply is not None else {},
                     reported_llm_cost_usd=reply.cost_usd if reply is not None else None,
                     response=reply.content if reply is not None else None, action=None,
                     final_success=None, error_type=generation_error)
        if generation_error is None:
            history.append({"role": "assistant", "content": reply.content})
            tick = time.perf_counter()
            try:
                action = parse_action(reply.content, names)
                event["action"] = action
            except (ValueError, TypeError) as exc:
                event["error_type"] = "InvalidAction:" + type(exc).__name__
            event["verification_seconds"] += _elapsed(tick)
            if event["action"] is not None:
                if action["type"] == "final":
                    tick = time.perf_counter()
                    success = environment.finish(action["answer"])
                    if type(success) is not bool:
                        raise TypeError("El evaluador final debe devolver bool.")
                    event["verification_seconds"] += _elapsed(tick)
                    event["final_success"] = success
                    termination = "final_answer"
                else:
                    tick = time.perf_counter()
                    result = environment.execute(action["name"], deepcopy(action["arguments"]))
                    event["tool_seconds"] = _elapsed(tick)
                    if (not isinstance(result, dict) or set(result) != {"ok", "observation", "error_type"}
                            or type(result["ok"]) is not bool):
                        raise TypeError("Contrato inválido de herramienta.")
                    history.append({"role": "tool", "content": {"name": action["name"], **deepcopy(result)}})
                    event["tool_result"] = deepcopy(result)
                    if not result["ok"]:
                        event["error_type"] = "ToolError:" + str(result["error_type"])
                    elif callable(getattr(environment, "verification_error", None)):
                        tick = time.perf_counter()
                        validation_error = environment.verification_error(action["name"], deepcopy(result))
                        event["verification_seconds"] += _elapsed(tick)
                        if validation_error is not None:
                            event["error_type"] = "VerificationFailed:" + str(validation_error)
        if event["error_type"] is not None:
            errors.append(event["error_type"])
            history.append({"role": "error", "content": {"error_type": event["error_type"]}})
            attempt += 1
        else:
            step += 1
            attempt = 0
        events.append(event)
        journal.append("call_completed", key, event)
        if event["final_success"] is not None:
            break  # The hidden final evaluator is NEVER an escalation signal.
    return _episode(task, policy, events, config, success, termination, _elapsed(started))


def _run_episodes_locked(tasks, policies, generate, output_dir, config, *, environment_factory=create_environment):
    """Execute or resume explicit callbacks; never start providers on its own."""
    if not callable(generate):
        raise TypeError("Se requiere un callback de generación explícito.")
    tasks, config, policies = deepcopy(tasks), deepcopy(config), list(policies)
    frozen = prepare_episodes(tasks, policies, output_dir, config, generate=generate,
                              environment_factory=environment_factory)
    output = Path(output_dir)
    allowed = {(task["id"], p.name) for task in tasks for p in policies}
    journal = _Journal(output, frozen["freeze_sha256"], allowed)
    summary_path = output / "summary.json"
    if summary_path.exists():
        result = _unseal(summary_path)
        if (result["freeze_sha256"] != frozen["freeze_sha256"]
                or result["journal_sha256"] != object_hash(journal.records)
                or {tuple(k) for k in result["completed_pairs"]} != allowed
                or len([r for r in journal.records if r["kind"] == "episode_completed"]) != len(allowed)):
            raise ValueError("Resumen y journal no coinciden.")
        return result
    episodes = []
    for task in tasks:
        for policy in policies:
            key = (task["id"], policy.name)
            existing = journal.for_key(key)
            if existing:
                episode = _recover(task, policy, existing, config)
            else:
                episode = _execute(task, policy, generate, config, journal, environment_factory)
            if not existing or existing[-1]["kind"] != "episode_completed":
                journal.append("episode_completed", key, episode)
            episodes.append(episode)
    if (frozen["source_files_sha256"] != _sources() or _read(output / "manifest.json") != frozen
            or frozen["policies"] != {p.name: p.manifest() for p in policies}
            or frozen["generation_source"] != _fingerprint(generate)
            or frozen["environment_source"] != _fingerprint(environment_factory)):
        raise ValueError("Fuentes o manifiesto cambiaron durante la ejecución.")
    metrics = summarize(episodes, config["roi"], bootstrap_replicates=config["bootstrap_replicates"],
                        seed=config["seed"])
    result = {"schema_version": 1, "freeze_sha256": frozen["freeze_sha256"],
              "journal_sha256": object_hash(journal.records),
              "completed_pairs": [[e["episode_id"], e["policy"]] for e in episodes],
              "configuration": config, "metrics": metrics,
              "n_episodes": len(episodes), "n_tasks": len(tasks),
              "execution_mode": config["execution_mode"], "independent_validation": False,
              "quality_claim": "infrastructure fixture only" if config["execution_mode"] == "simulated"
              else "exploratory episode evaluation; no independent adoption claim"}
    _write(summary_path, _seal(result))
    return result


def run_episodes(tasks, policies, generate, output_dir, config, *, environment_factory=create_environment):
    """One writer, explicit generation callback and independent episode states."""
    if not callable(generate):
        raise TypeError("Se requiere un callback de generación explícito.")
    tasks, config, policies = deepcopy(tasks), deepcopy(config), list(policies)
    _validate(config, policies)
    validate_task_splits({config["evaluation_split"]: tasks})
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    with _single_writer(output):
        return _run_episodes_locked(tasks, policies, generate, output, config,
                                    environment_factory=environment_factory)
